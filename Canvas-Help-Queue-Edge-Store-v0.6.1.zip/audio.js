(function (root) {
  'use strict';
  const MAX_BYTES = 5 * 1024 * 1024;
  function parseMidi(buffer) {
    const bytes = new Uint8Array(buffer), data = new DataView(buffer);
    const fail = () => { throw new Error('This MIDI file is incomplete or invalid.'); };
    const tag = p => String.fromCharCode(...bytes.subarray(p, p + 4));
    if (bytes.length < 14 || tag(0) !== 'MThd') fail();
    const headerSize = data.getUint32(4), format = data.getUint16(8), tracks = data.getUint16(10), division = data.getUint16(12);
    if (headerSize < 6 || 8 + headerSize > bytes.length || !tracks || tracks > 256 || !division) fail();
    if (format > 1) throw new Error('Choose a standard MIDI format 0 or 1 file. Format 2 and MIDI 2.0 clips are not supported.');
    if (format === 0 && tracks !== 1) fail();
    let secondsPerTick;
    if (division & 0x8000) {
      const fps = 256 - (division >> 8), ticks = division & 255;
      if (![24, 25, 29, 30].includes(fps) || !ticks) fail();
      secondsPerTick = 1 / ((fps === 29 ? 30000 / 1001 : fps) * ticks);
    }
    let position = 8 + headerSize, eventCount = 0, endTick = 0;
    const events = [];
    for (let track = 0; track < tracks; track++) {
      if (position + 8 > bytes.length || tag(position) !== 'MTrk') fail();
      const end = position + 8 + data.getUint32(position + 4);
      position += 8;
      if (end > bytes.length) fail();
      let tick = 0, running = 0;
      function byte() { if (position >= end) fail(); return bytes[position++]; }
      function vlq() {
        let value = 0;
        for (let n = 0; n < 4; n++) { const b = byte(); value = value * 128 + (b & 127); if (!(b & 128)) return value; }
        fail();
      }
      while (position < end) {
        if (++eventCount > 100000) throw new Error('This MIDI file has too many events. Choose a shorter file.');
        tick += vlq(); endTick = Math.max(endTick, tick);
        let status = byte();
        if (status < 128) { if (!running) fail(); position--; status = running; }
        if (status === 255) {
          running = 0;
          const type = byte(), length = vlq();
          if (position + length > end) fail();
          if (type === 0x51) {
            if (length !== 3) fail();
            const tempo = bytes[position] * 65536 + bytes[position + 1] * 256 + bytes[position + 2];
            if (!tempo) fail();
            events.push({ tick, kind: 'tempo', tempo });
          }
          position += length;
          if (type === 0x2f) break;
        } else if (status === 0xf0 || status === 0xf7) {
          running = 0; const length = vlq(); if (position + length > end) fail(); position += length;
        } else {
          if (status >= 0xf0) fail();
          running = status;
          const kind = status >> 4, channel = status & 15;
          const a = byte(), b = kind === 0xc || kind === 0xd ? 0 : byte();
          if (a > 127 || b > 127) fail();
          if (kind === 0x8 || kind === 0x9) events.push({ tick, kind: kind === 0x9 && b > 0 ? 'on' : 'off', channel, pitch: a, velocity: b });
          else if (kind === 0xb) events.push({ tick, kind: 'control', channel, control: a, value: b });
          else if (kind === 0xc) events.push({ tick, kind: 'program', channel, program: a });
        }
      }
      position = end;
    }
    events.sort((a, b) => a.tick - b.tick);
    const active = new Map(), sustained = Array.from({ length: 16 }, () => []), pedal = Array(16).fill(false), programs = Array(16).fill(0), notes = [];
    let tick = 0, seconds = 0, tempo = 500000;
    const close = (note, time) => { note.duration = Math.max(0.03, time - note.start); notes.push(note); };
    for (const event of events) {
      seconds += (event.tick - tick) * (secondsPerTick || tempo / 1000000 / division); tick = event.tick;
      if (seconds > 1800) throw new Error('Choose a MIDI song shorter than 30 minutes.');
      if (event.kind === 'tempo') { tempo = event.tempo; continue; }
      const channel = event.channel, key = `${channel}:${event.pitch}`;
      if (event.kind === 'program') programs[channel] = event.program;
      if (event.kind === 'on') {
        const list = active.get(key) || [];
        list.push({ start: seconds, pitch: event.pitch, velocity: event.velocity, program: programs[channel], channel }); active.set(key, list);
      }
      if (event.kind === 'off') {
        const list = active.get(key), note = list?.shift();
        if (!list?.length) active.delete(key);
        if (note) { if (pedal[channel]) sustained[channel].push(note); else close(note, seconds); }
      }
      if (event.kind === 'control') {
        if (event.control === 64) {
          pedal[channel] = event.value >= 64;
          if (!pedal[channel]) { sustained[channel].forEach(note => close(note, seconds)); sustained[channel] = []; }
        }
        if ([120, 123].includes(event.control)) {
          for (const [key, list] of active) if (list[0]?.channel === channel) { list.forEach(note => close(note, seconds)); active.delete(key); }
          sustained[channel].forEach(note => close(note, seconds)); sustained[channel] = [];
        }
      }
    }
    seconds += (endTick - tick) * (secondsPerTick || tempo / 1000000 / division);
    if (seconds > 1800) throw new Error('Choose a MIDI song shorter than 30 minutes.');
    for (const list of active.values()) list.forEach(note => close(note, Math.max(seconds, note.start + 0.25)));
    sustained.flat().forEach(note => close(note, seconds));
    if (!notes.length) throw new Error('This MIDI file has no playable notes.');
    if (notes.length > 20000) throw new Error('This MIDI song has too many notes. Choose a shorter file.');
    notes.sort((a, b) => a.start - b.start);
    return { notes, duration: Math.max(...notes.map(note => note.start + note.duration)) };
  }
  function fileKind(name) {
    if (/\.(mid|midi)$/i.test(name)) return 'midi';
    if (/\.(wav|mp3)$/i.test(name)) return 'audio';
    throw new Error('Choose a MIDI (.mid or .midi), WAV, or MP3 file.');
  }
  function encode(buffer) {
    const bytes = new Uint8Array(buffer); let binary = '';
    for (let p = 0; p < bytes.length; p += 16384) binary += String.fromCharCode(...bytes.subarray(p, p + 16384));
    return btoa(binary);
  }
  function decode(base64) {
    if (typeof base64 !== 'string' || base64.length > Math.ceil(MAX_BYTES / 3) * 4) throw new Error('Saved sound is invalid or too large.');
    return Uint8Array.from(atob(base64), char => char.charCodeAt(0)).buffer;
  }
  class Player {
    constructor(contextFactory = () => new AudioContext()) {
      this.contextFactory = contextFactory; this.nodes = new Set(); this.volume = 0.6;
    }
    context() {
      if (!this.audio) {
        this.audio = this.contextFactory();
        this.master = this.audio.createGain(); this.master.gain.value = this.volume;
        const limiter = this.audio.createDynamicsCompressor(); this.master.connect(limiter); limiter.connect(this.audio.destination);
      }
      return this.audio;
    }
    unlock() { const context = this.context(); return context.resume(); }
    get ready() { return this.audio?.state === 'running'; }
    setVolume(value) { this.volume = Math.max(0, Math.min(1, Number(value) || 0)); if (this.master) this.master.gain.value = this.volume; }
    async load(record) {
      let prepared = null;
      if (record) {
        const kind = fileKind(record.name), buffer = decode(record.data);
        if (!buffer.byteLength || buffer.byteLength > MAX_BYTES) throw new Error('Choose a sound file up to 5 MB.');
        if (kind === 'midi') prepared = { kind, ...parseMidi(buffer) };
        else {
          let decoded;
          let timeout;
          try {
            decoded = await Promise.race([
              this.context().decodeAudioData(buffer),
              new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error('Audio decoding timed out. Try another MP3 or WAV file.')), 20000); }),
            ]);
          } catch (error) {
            throw new Error(error.message.includes('timed out') ? error.message : 'Cannot decode this file. Choose a valid MP3 or WAV file.');
          } finally { clearTimeout(timeout); }
          prepared = { kind, buffer: decoded, duration: decoded.duration };
        }
      }
      this.stop(); this.prepared = prepared;
    }
    note(pitch, velocity, start, duration, program = 0) {
      const audio = this.context(), oscillator = audio.createOscillator(), gain = audio.createGain();
      oscillator.type = program >= 32 && program < 40 ? 'sine' : 'triangle';
      oscillator.frequency.value = 440 * 2 ** ((pitch - 69) / 12);
      gain.gain.setValueAtTime(0, start); gain.gain.linearRampToValueAtTime(velocity / 127 * 0.12, start + 0.01);
      gain.gain.setValueAtTime(velocity / 127 * 0.09, start + Math.max(0.01, duration - 0.02));
      gain.gain.linearRampToValueAtTime(0, start + duration + 0.06);
      oscillator.connect(gain); gain.connect(this.master); this.nodes.add(oscillator);
      oscillator.onended = () => { this.nodes.delete(oscillator); oscillator.disconnect(); gain.disconnect(); };
      oscillator.start(start); oscillator.stop(start + duration + 0.07);
    }
    play({ restart = false } = {}) {
      if (!this.ready) return false;
      if (this.playing && !restart) return true;
      this.stop(); this.playing = true; const playToken = this.playToken;
      const audio = this.audio, prepared = this.prepared, start = audio.currentTime + 0.025;
      if (!prepared) {
        this.note(76, 95, start, 0.12); this.note(81, 95, start + 0.14, 0.18);
      } else if (prepared.kind === 'audio') {
        const node = audio.createBufferSource(); node.buffer = prepared.buffer; node.connect(this.master); this.nodes.add(node);
        node.onended = () => { this.nodes.delete(node); node.disconnect(); if (playToken === this.playToken) this.playing = false; };
        node.start(start);
      } else {
        let index = 0;
        const schedule = () => {
          if (!this.playing) return;
          const ahead = audio.currentTime + 0.25;
          while (index < prepared.notes.length && start + prepared.notes[index].start < ahead) {
            const note = prepared.notes[index++];
            const at = start + note.start, end = at + note.duration;
            if (end > audio.currentTime && this.nodes.size < 64) this.note(note.pitch, note.velocity, Math.max(audio.currentTime, at), Math.max(0.03, end - Math.max(audio.currentTime, at)), note.program);
          }
          if (index < prepared.notes.length) this.scheduler = setTimeout(schedule, 100);
        };
        schedule();
      }
      this.endTimer = setTimeout(() => { this.playing = false; }, ((prepared?.duration || 0.5) + 0.2) * 1000);
      return true;
    }
    stop() {
      this.playToken = (this.playToken || 0) + 1;
      clearTimeout(this.scheduler); clearTimeout(this.endTimer); this.playing = false;
      for (const node of this.nodes) { try { node.stop(); } catch {} } this.nodes.clear();
    }
    destroy() { this.stop(); this.audio?.close().catch(() => {}); }
  }
  const api = { Player, parseMidi, fileKind, encode, decode, MAX_BYTES };
  root.CanvasHelpQueueAudio = api;
  if (typeof module !== 'undefined') module.exports = api;
})(globalThis);
