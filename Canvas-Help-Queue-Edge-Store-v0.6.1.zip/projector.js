'use strict';
const ext = typeof browser !== 'undefined' ? browser : chrome;
const params = new URLSearchParams(location.search);
const sourceTab = Number(params.get('sourceTab'));
const sourceKey = params.get('sourceKey');
let timer, busy = false, ended = false, previousSignature;
const $ = id => document.getElementById(id);
$('fullscreen').onclick = async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await document.documentElement.requestFullscreen();
  } catch { $('fullscreen').textContent = 'Use F11 for full screen'; }
};
document.addEventListener('fullscreenchange', () => { $('fullscreen').textContent = document.fullscreenElement ? 'Exit full screen' : 'Full screen'; });
function disconnected(message) {
  $('status').className = 'error'; $('status').textContent = message;
  $('count').textContent = '—'; $('queue').replaceChildren(); $('empty').hidden = true;
  $('updated').textContent = 'Connection paused'; previousSignature = undefined;
}
function display(state) {
  $('discussion').textContent = `${state.title} · Course ${state.courseId}${state.dayLabel ? ` · Today, ${state.dayLabel}` : ''}`;
  $('title').textContent = state.waiting.length ? 'Your turn is coming.' : 'Ready when you are.';
  $('count').textContent = String(state.waiting.length);
  document.querySelector('.summary span').textContent = state.waiting.length === 1 ? 'request waiting' : 'requests waiting';
  const stale = !state.lastSuccess || Date.now() - state.lastSuccess > Math.max(20000, state.interval * 3);
  $('status').className = state.error || stale ? 'error' : '';
  $('status').textContent = state.error ? `${state.error} Showing the last successful queue.` : stale ? 'Updates are delayed. Check the original Canvas tab. This list may be out of date.' : 'Live queue · first come, first served';
  $('updated').textContent = state.lastSuccess ? `Last checked ${new Date(state.lastSuccess).toLocaleTimeString()}` : 'Waiting for first check';
  document.querySelector('footer span:last-child').textContent = `Linked to your original Canvas tab · checks every ${state.interval / 1000} seconds`;
  $('empty').hidden = state.waiting.length > 0 || stale || Boolean(state.error);
  const signature = JSON.stringify(state.waiting);
  if (signature === previousSignature) return;
  previousSignature = signature; $('queue').replaceChildren();
  state.waiting.forEach((entry, index) => {
    const row = document.createElement('li');
    const place = document.createElement('span'); place.className = 'place'; place.textContent = String(index + 1);
    const name = document.createElement('span'); name.className = 'name'; name.textContent = entry.name;
    const ahead = document.createElement('span'); ahead.className = 'ahead'; ahead.textContent = index === 0 ? 'You’re next' : `${index} ahead`;
    row.append(place, name, ahead); $('queue').append(row);
  });
}
async function sync() {
  if (busy || ended) return;
  busy = true;
  let timeout;
  try {
    const state = await Promise.race([
      ext.tabs.sendMessage(sourceTab, { type: 'chq:snapshot', sourceKey }),
      new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error('Source tab did not respond.')), 2500); }),
    ]);
    if (!state || state.disconnected) throw new Error('Discussion connection stopped.');
    display(state);
  } catch {
    disconnected('Connection paused. Keep the original Canvas discussion tab open. If it was refreshed, click the Help Queue extension in that tab again.');
  } finally {
    clearTimeout(timeout); busy = false;
    if (!ended) timer = setTimeout(sync, 1000);
  }
}
window.addEventListener('pagehide', () => { ended = true; clearTimeout(timer); });
if (!Number.isInteger(sourceTab) || sourceTab <= 0 || !sourceKey) disconnected('Open this window using “Open projector window” in your Canvas Help Queue.');
else sync();
