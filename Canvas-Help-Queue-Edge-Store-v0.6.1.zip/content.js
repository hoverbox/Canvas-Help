(function () {
  'use strict';
  if (globalThis.__canvasHelpQueue) { globalThis.__canvasHelpQueue.show(); return; }
  const ext = typeof browser !== 'undefined' ? browser : chrome;
  const core = globalThis.CanvasHelpQueueCore;
  let config;
  try { config = core.parseDiscussion(location.href); } catch { return; }
  const host = document.createElement('div');
  host.id = 'canvas-help-queue';
  host.style.cssText = 'position:fixed;inset:0 0 auto auto;z-index:2147483647;';
  document.documentElement.append(host);
  const shadow = host.attachShadow({ mode: 'open' });
  const style = document.createElement('link');
  style.rel = 'stylesheet'; style.href = ext.runtime.getURL('panel.css'); shadow.append(style);
  const projectorStyle = document.createElement('link');
  projectorStyle.rel = 'stylesheet'; projectorStyle.href = ext.runtime.getURL('projector-button.css'); shadow.append(projectorStyle);
  const panel = document.createElement('section'); panel.className = 'panel'; panel.setAttribute('aria-label', 'Canvas Help Queue'); shadow.append(panel);
  // Only extension-owned constant markup is parsed. Canvas names/messages use textContent.
  panel.innerHTML = `
    <header><div><span class="eyebrow">CLASSROOM TOOLS</span><h1>Help Queue <span class="live-dot" aria-hidden="true"></span></h1></div><button class="icon" id="hide" aria-label="Minimize queue" title="Keep watching, hide the panel">−</button></header>
    <div class="topic"><strong id="topic">Connecting to Canvas…</strong><span id="context">This discussion</span><span id="dayLabel"></span></div>
    <div class="summary"><div><b id="waiting">0</b><span>requests waiting</span></div><button id="refresh" class="secondary">Check now</button></div>
    <div id="status" role="status" aria-live="polite">Checking your Canvas login…</div>
    <div class="audio-strip"><span id="soundState" role="status">Sound is on</span><button id="enableAudio" class="text-button">Enable sound</button></div>
    <button id="projector" class="secondary projector-button" disabled>Open projector window ↗</button>
    <div class="toolbar"><div class="tabs" role="group" aria-label="Queue filter"><button id="pending" aria-pressed="true">Today</button><button id="earlier" aria-pressed="false" aria-label="Earlier unfinished requests">Earlier <span id="earlierCount">0</span></button><button id="completed" aria-pressed="false">Done <span id="doneCount">0</span></button></div><button id="settingsButton" class="text-button" aria-expanded="false">Settings</button></div>
    <div id="historyControls" hidden><label>Posted on <input type="date" id="historyDate" aria-label="Filter earlier requests by posted date"></label><button id="allHistory" class="text-button">All earlier dates</button><p>Unfinished requests outside today. These stay off the projector.</p></div>
    <div id="settings" hidden>
      <label>Include posts<select id="mode"><option value="requests">Help / check / lesson / grade / stuck / assistance</option><option value="all">Every post (dedicated help discussion)</option></select></label>
      <label class="check-label"><input type="checkbox" id="fuzzy" checked> Allow spelling mistakes</label>
      <p>Accepts close spellings like “hepl,” “halp,” “chek,” and “leson.”</p>
      <label>Check for requests<select id="interval"><option value="5000">Every 5 seconds</option><option value="15000">Every 15 seconds</option><option value="30000">Every 30 seconds</option><option value="60000">Every minute</option></select></label>
      <label class="check-label"><input type="checkbox" id="sound" checked> Play a sound for new requests</label>
      <label>Notification sound</label>
      <button id="chooseAudio" class="secondary" type="button">Choose sound file…</button>
      <input id="audioFile" type="file" accept=".mid,.midi,.wav,.mp3,audio/midi,audio/wav,audio/mpeg" hidden aria-label="Choose notification sound file">
      <p id="audioName">Default chime · choose MIDI, WAV, or MP3 (up to 5 MB)</p>
      <div class="audio-actions"><button id="previewAudio" class="secondary">Preview sound</button><button id="stopAudio" class="secondary">Stop sound</button><button id="resetAudio" class="text-button">Use default chime</button></div>
      <label>Volume <input id="volume" type="range" min="0" max="100" value="60" aria-label="Notification volume"></label>
      <p id="audioMessage" role="status"></p>
      <label class="check-label"><input type="checkbox" id="includeOwn"> Include my own posts for testing</label>
      <p>Students should post a new reply to the discussion itself. Replies to classmates are not included. Your own posts are excluded unless testing is enabled.</p>
      <button class="text-button" id="stop">Stop watching this tab</button>
    </div>
    <div id="queue" class="queue" aria-label="Requests"></div>
    <footer><span id="updated">Waiting for first check</span><span>Saved on this computer</span></footer>
    <p class="footnote">Keep this discussion tab open. Done tracks help or checks here; enter grades in Canvas as usual.</p>`;
  const $ = (id) => shadow.getElementById(id);
  const launcher = document.createElement('button');
  launcher.className = 'launcher'; launcher.hidden = true; launcher.textContent = 'Help Queue · 0'; shadow.append(launcher);
  let entries = [], done = {}, prefs = { mode: 'requests', fuzzy: true, interval: 5000, sound: true, volume: 60, soundVersion: 1, includeOwn: false, refreshVersion: 1 };
  let userId, scope, prefsKey, timer, view = 'pending', polling = false, initialized = false, stopped = false, projectorWindowId;
  let errorCount = 0, lastError = '', seen = new Set(), lastSuccess = null, customAudio;
  const audioTools = globalThis.CanvasHelpQueueAudio;
  const player = new audioTools.Player();
  const audioKey = 'chq:custom-audio:v1';
  const toText = (html) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    doc.querySelectorAll('script,style').forEach((node) => node.remove());
    doc.querySelectorAll('br,p,div,li').forEach((node) => node.append(doc.createTextNode(' ')));
    return doc.body.textContent.replace(/\s+/g, ' ').trim();
  };
  const doneKey = (id) => `${scope}:done:${id}`;
  function badge(count, error = false) {
    ext.runtime.sendMessage({ type: 'chq:badge', count, error }).catch(() => {});
  }
  function show() { panel.hidden = false; launcher.hidden = true; }
  globalThis.__canvasHelpQueue = { show };
  $('hide').onclick = () => { panel.hidden = true; launcher.hidden = false; };
  launcher.onclick = show;
  $('settingsButton').onclick = () => {
    $('settings').hidden = !$('settings').hidden;
    $('settingsButton').setAttribute('aria-expanded', String(!$('settings').hidden));
  };
  $('pending').onclick = () => { view = 'pending'; render(); };
  $('earlier').onclick = () => { view = 'earlier'; render(); };
  $('completed').onclick = () => { view = 'done'; render(); };
  $('historyDate').oninput = render;
  $('allHistory').onclick = () => { $('historyDate').value = ''; render(); };
  $('refresh').onclick = () => { clearTimeout(timer); return poll(); };
  $('projector').onclick = async () => {
    try {
      const result = await ext.runtime.sendMessage({ type: 'chq:projector', sourceKey: scope, windowId: projectorWindowId });
      if (result?.error) throw new Error(result.error);
      projectorWindowId = result?.windowId;
    } catch (error) { status(`Could not open projector window: ${error.message}`, true); }
  };
  function projectorSnapshot(message, sender, sendResponse) {
    if (message?.type !== 'chq:snapshot') return;
    if (stopped || !scope || message.sourceKey !== scope) {
      sendResponse({ disconnected: true }); return;
    }
    sendResponse({
      title: $('topic').textContent, courseId: config.courseId,
      dayLabel: new Date().toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }),
      waiting: core.partitionEntries(entries, done).today.map(entry => ({ id: entry.id, name: entry.name })),
      lastSuccess: lastSuccess?.getTime() || null, interval: prefs.interval, error: lastError,
    });
  }
  ext.runtime.onMessage?.addListener(projectorSnapshot);
  $('stop').onclick = () => {
    stopped = true; clearTimeout(timer); clearInterval(ageTimer);
    ext.storage.onChanged.removeListener(storageChanged); badge(0);
    ext.runtime.onMessage?.removeListener(projectorSnapshot);
    document.removeEventListener('pointerdown', audioGesture, true);
    document.removeEventListener('keydown', audioGesture, true);
    player.destroy();
    host.remove(); delete globalThis.__canvasHelpQueue;
  };
  async function settingsChanged() {
    prefs = { ...prefs, mode: $('mode').value, fuzzy: $('fuzzy').checked, interval: Number($('interval').value), sound: $('sound').checked, volume: Number($('volume').value), soundVersion: 1, includeOwn: $('includeOwn').checked, refreshVersion: 1 };
    player.setVolume(prefs.volume / 100);
    if (prefs.sound) armSound(); else player.stop();
    soundState();
    initialized = false;
    if (prefsKey) {
      try { await ext.storage.local.set({ [prefsKey]: prefs }); }
      catch { status('Settings could not be saved. Check extension storage.', true); }
    }
    clearTimeout(timer); return poll();
  }
  $('mode').onchange = settingsChanged;
  $('fuzzy').onchange = settingsChanged;
  $('interval').onchange = settingsChanged;
  $('sound').onchange = settingsChanged;
  $('includeOwn').onchange = settingsChanged;
  $('volume').oninput = () => player.setVolume(Number($('volume').value) / 100);
  $('volume').onchange = settingsChanged;
  function soundState() {
    $('enableAudio').hidden = !prefs.sound || player.ready;
    $('soundState').textContent = !prefs.sound ? 'Sound off' : player.ready ? 'Sound on' : 'Sound on · click Enable sound once';
    $('audioName').textContent = customAudio ? `Selected sound: ${customAudio.name}` : 'Default chime · choose MIDI, WAV, or MP3 (up to 5 MB)';
  }
  function armSound() {
    if (stopped || !prefs.sound) return;
    try {
      player.context().onstatechange = soundState;
      player.unlock().then(soundState).catch(soundState);
    } catch { $('soundState').textContent = 'Audio unavailable in this browser session'; return; }
    soundState();
  }
  function audioGesture(event) { if (event.isTrusted && prefs.sound && !player.ready) armSound(); }
  document.addEventListener('pointerdown', audioGesture, true);
  document.addEventListener('keydown', audioGesture, true);
  $('enableAudio').onclick = armSound;
  $('previewAudio').onclick = async () => {
    try { await player.unlock(); player.play({ restart: true }); soundState(); $('audioMessage').textContent = 'Playing preview.'; }
    catch { $('audioMessage').textContent = 'Could not play sound. Check your browser audio settings.'; }
  };
  $('stopAudio').onclick = () => { player.stop(); $('audioMessage').textContent = 'Sound stopped.'; };
  $('chooseAudio').onclick = () => { $('audioFile').value = ''; $('audioFile').click(); };
  function audioMessage(message, error = false) {
    $('audioMessage').textContent = message;
    $('audioMessage').className = error ? 'audio-error' : '';
  }
  function readAudioFile(file) {
    // FileReader works with native File objects exposed to Firefox content scripts.
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      const timeout = setTimeout(() => { reader.abort(); reject(new Error('Reading the file took too long. Please choose it again.')); }, 20000);
      reader.onload = () => { clearTimeout(timeout); resolve(reader.result); };
      reader.onerror = () => { clearTimeout(timeout); reject(new Error('Could not read this file. Copy it to a local folder and try again.')); };
      reader.onabort = () => { clearTimeout(timeout); reject(new Error('File reading was interrupted. Please choose it again.')); };
      reader.readAsArrayBuffer(file);
    });
  }
  $('audioFile').onchange = async () => {
    const file = $('audioFile').files[0]; if (!file) return;
    armSound(); $('chooseAudio').disabled = true; $('previewAudio').disabled = true; $('resetAudio').disabled = true;
    audioMessage(`Loading ${file.name}…`);
    try {
      audioTools.fileKind(file.name);
      if (!file.size || file.size > audioTools.MAX_BYTES) throw new Error('Choose a sound file up to 5 MB.');
      const record = { name: file.name, data: audioTools.encode(await readAudioFile(file)) };
      await player.load(record); if (stopped) return;
      customAudio = record; soundState();
      try { await ext.storage.local.set({ [audioKey]: record }); }
      catch { audioMessage(`Loaded ${file.name} for this tab, but could not save it. Try a smaller file.`, true); return; }
      $('sound').checked = true; await settingsChanged();
      audioMessage(`Loaded and saved ${file.name}. Click Preview sound to listen.${/\.(mid|midi)$/i.test(file.name) ? ' MIDI uses synthesized tones.' : ''}`);
    } catch (error) { audioMessage(`Could not load ${file.name}: ${error.message}`, true); }
    finally { $('chooseAudio').disabled = false; $('previewAudio').disabled = false; $('resetAudio').disabled = false; }
  };
  $('resetAudio').onclick = async () => {
    try { await ext.storage.local.remove(audioKey); await player.load(null); customAudio = null; soundState(); $('audioMessage').textContent = 'Default chime restored.'; }
    catch { $('audioMessage').textContent = 'Could not restore the default. Please try again.'; }
  };
  function status(message, error = false) {
    $('status').textContent = message; $('status').className = error ? 'error' : '';
    panel.classList.toggle('has-error', error);
  }
  function render() {
    const { today: waiting, earlier, completed } = core.partitionEntries(entries, done);
    $('dayLabel').textContent = `Today · ${new Date().toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}`;
    $('waiting').textContent = String(waiting.length);
    panel.querySelector('.summary span').textContent = waiting.length === 1 ? 'request today' : 'requests today';
    $('earlierCount').textContent = String(earlier.length);
    $('historyControls').hidden = view !== 'earlier';
    $('doneCount').textContent = String(completed.length);
    launcher.textContent = `Help Queue · ${waiting.length}${lastError ? ' · !' : ''}`;
    badge(waiting.length, Boolean(lastError));
    $('projector').disabled = !scope || !lastSuccess || stopped;
    $('pending').setAttribute('aria-pressed', String(view === 'pending'));
    $('earlier').setAttribute('aria-pressed', String(view === 'earlier'));
    $('completed').setAttribute('aria-pressed', String(view === 'done'));
    $('queue').replaceChildren();
    const visible = view === 'pending' ? waiting : view === 'earlier' ? earlier.filter(entry => !$('historyDate').value || core.localDateKey(entry.createdAt) === $('historyDate').value) : [...completed].reverse();
    if (!visible.length) {
      const empty = document.createElement('div'); empty.className = 'empty';
      const heading = document.createElement('strong');
      heading.textContent = !lastSuccess ? (lastError ? 'Waiting to connect' : 'Loading requests…') : view === 'pending' ? 'All caught up today' : view === 'earlier' ? 'No earlier requests to show' : 'No completed requests yet';
      const detail = document.createElement('p');
      detail.textContent = !lastSuccess ? 'Your queue will appear after Canvas responds. See the connection status above.' : view === 'pending' ? (prefs.includeOwn ? 'Today’s matching posts appear here, including your own test posts. Review unfinished older posts under Earlier.' : 'Today’s student requests appear here. Missed someone previously? Open Earlier. For teacher testing, enable your own posts in Settings.') : view === 'earlier' ? ($('historyDate').value ? 'Try another date or choose All earlier dates.' : 'Requests you don’t finish today will be available here on the next day.') : 'Check a request after helping a student. You can undo it here.';
      empty.append(heading, detail); $('queue').append(empty);
    }
    for (const entry of visible) {
      const card = document.createElement('article'); card.className = 'card';
      const row = document.createElement('label'); row.className = 'card-title';
      const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = Boolean(done[entry.id]);
      checkbox.setAttribute('aria-label', `${checkbox.checked ? 'Reopen' : 'Mark done'}: ${entry.name}`);
      const name = document.createElement('strong'); name.textContent = entry.name;
      row.append(checkbox, name);
      const text = document.createElement('p'); text.className = 'request'; text.textContent = entry.text;
      const posted = document.createElement('p'); posted.className = 'posted';
      const timestamp = new Date(entry.createdAt || NaN);
      posted.textContent = Number.isFinite(timestamp.getTime()) ? `Posted ${timestamp.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })} · ${timestamp.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}` : 'Posted date unavailable';
      const bottom = document.createElement('div'); bottom.className = 'card-bottom';
      const time = document.createElement('span');
      time.textContent = done[entry.id] ? 'Completed' : `Waiting · ${core.waitingTime(entry.createdAt)}`;
      if (entry.createdAt) time.title = new Date(entry.createdAt).toLocaleString();
      const link = document.createElement('a');
      link.href = `${config.origin}/courses/${config.courseId}/discussion_topics/${config.topicId}`;
      link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = 'Open discussion ↗';
      bottom.append(time, link); card.append(row, text, posted, bottom); $('queue').append(card);
      checkbox.onchange = async () => {
        const checked = checkbox.checked;
        checkbox.disabled = true;
        try {
          if (checked) await ext.storage.local.set({ [doneKey(entry.id)]: Date.now() });
          else await ext.storage.local.remove(doneKey(entry.id));
          if (stopped) return;
          if (checked) done[entry.id] = true; else delete done[entry.id];
          render();
        } catch {
          checkbox.checked = !checked; checkbox.disabled = false;
          status('Could not save that checkbox. Please try again.', true);
        }
      };
    }
  }
  function storageChanged(changes, area) {
    if (area !== 'local' || !scope || stopped) return;
    if (changes[audioKey] && changes[audioKey].newValue?.data !== customAudio?.data) {
      const record = changes[audioKey].newValue || null;
      player.load(record).then(() => { customAudio = record; soundState(); }).catch(error => { $('audioMessage').textContent = error.message; });
    }
    let changed = false;
    for (const [key, value] of Object.entries(changes)) {
      if (!key.startsWith(`${scope}:done:`)) continue;
      const id = key.slice(`${scope}:done:`.length);
      if (value.newValue) done[id] = true; else delete done[id];
      changed = true;
    }
    if (changed) render();
  }
  ext.storage.onChanged.addListener(storageChanged);
  async function connect() {
    const { data: account } = await core.getJSON(`${config.origin}/api/v1/users/self/profile`);
    if (!account?.id) throw new Error('Could not identify your Canvas account. Sign in and try again.');
    if (userId && String(userId) !== String(account.id)) {
      stopped = true; clearInterval(ageTimer);
      player.destroy();
      ext.storage.onChanged.removeListener(storageChanged);
      entries = []; done = {}; lastSuccess = null;
      throw new Error('Canvas account changed. Stop watching and start again for this account.');
    }
    userId = account.id;
    if (!scope) {
      const stored = await ext.storage.local.get(null);
      scope = `chq:v1:${config.origin}:${userId}:${config.courseId}:${config.topicId}`;
      prefsKey = `${scope}:prefs`;
      prefs = { ...prefs, ...stored[prefsKey] };
      // Upgrade the original prototype's slower saved default once.
      if (stored[prefsKey] && stored[prefsKey].refreshVersion !== 1) prefs.interval = 5000;
      if (!['requests', 'all'].includes(prefs.mode)) prefs.mode = 'requests';
      if (![5000, 15000, 30000, 60000].includes(prefs.interval)) prefs.interval = 5000;
      // The new default is on. Future explicit mute choices remain saved.
      prefs.sound = stored[prefsKey]?.soundVersion === 1 ? stored[prefsKey].sound !== false : true;
      prefs.volume = Number.isFinite(prefs.volume) ? Math.max(0, Math.min(100, prefs.volume)) : 60;
      $('sound').checked = prefs.sound; $('volume').value = String(prefs.volume); player.setVolume(prefs.volume / 100);
      try { await player.load(stored[audioKey] || null); customAudio = stored[audioKey] || null; }
      catch (error) { $('audioMessage').textContent = error.message; }
      soundState(); armSound();
      $('mode').value = prefs.mode; $('interval').value = String(prefs.interval);
      prefs.fuzzy = prefs.fuzzy !== false; $('fuzzy').checked = prefs.fuzzy;
      prefs.includeOwn = prefs.includeOwn === true;
      $('includeOwn').checked = prefs.includeOwn;
      for (const [key, value] of Object.entries(stored)) {
        if (key.startsWith(`${scope}:done:`) && value) done[key.slice(`${scope}:done:`.length)] = true;
      }
    }
    const { data: topic } = await core.getJSON(`${config.origin}/api/v1/courses/${config.courseId}/discussion_topics/${config.topicId}`);
    if (!topic?.id || !topic.title) throw new Error('This page did not return a Canvas discussion.');
    if (topic.group_category_id || topic.group_topic_children?.length || topic.is_announcement) {
      throw new Error('Use a regular course discussion for the queue. Group discussions and announcements are not supported in this version.');
    }
    if (topic.anonymous_state && topic.anonymous_state !== 'off') throw new Error('Use a non-anonymous discussion so students can be identified.');
    $('topic').textContent = topic.title;
    $('context').textContent = `Course ${config.courseId} · ${account.name || account.short_name || 'Your Canvas account'}`;
  }
  async function poll() {
    if (stopped || polling) return;
    polling = true; $('refresh').disabled = true;
    let delay = prefs.interval;
    try {
      await connect();
      const raw = await core.fetchEntries(config);
      if (stopped) return;
      const fresh = core.selectEntries(raw, { userId, mode: prefs.mode, includeOwn: prefs.includeOwn, fuzzy: prefs.fuzzy }, toText);
      const arrivals = core.partitionEntries(fresh, done).today.filter(entry => !seen.has(entry.id));
      if (initialized && arrivals.length && prefs.sound) { player.play(); soundState(); }
      entries = fresh; seen = new Set(fresh.map((entry) => entry.id)); initialized = true;
      errorCount = 0; lastError = ''; lastSuccess = new Date(); delay = prefs.interval;
      status(`Watching · checks every ${prefs.interval / 1000} seconds${prefs.includeOwn ? ' · Testing: includes your posts' : ''}`);
      $('updated').textContent = `Checked ${lastSuccess.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
    } catch (error) {
      if (stopped && !error.message.includes('account changed')) return;
      lastError = error.message; errorCount += 1;
      delay = Math.min(300000, Math.max(prefs.interval, 15000 * 2 ** Math.min(errorCount, 5), error.retryMs || 0));
      status(lastError + (lastSuccess ? ' Showing the last successful check.' : ''), true);
    } finally {
      polling = false;
      if (!stopped) { $('refresh').disabled = false; render(); timer = setTimeout(poll, delay); }
      else if (lastError) { render(); $('refresh').disabled = true; }
    }
  }
  const ageTimer = setInterval(() => { if (!panel.hidden && !stopped && !shadow.activeElement?.closest('.card')) render(); }, 60000);
  armSound();
  poll();
})();
