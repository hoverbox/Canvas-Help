(function () {
  'use strict';
  const characters = {
    green: { frames: 6, label: 'Green slime' },
    orange: { frames: 6, label: 'Orange orb' },
    red: { frames: 6, label: 'Red slime' },
    blue: { frames: 7, label: 'Blue creature' },
  };
  const select = document.getElementById('characterSelect');
  const lane = document.getElementById('characterLane');
  const sprite = document.getElementById('walkingCharacter');
  const ext = typeof browser !== 'undefined' ? browser : chrome;
  const key = 'chq:projector-character:v1';
  const scriptBase = new URL('.', document.currentScript.src);
  let chosen = false;
  function apply(choice) {
    const character = characters[choice];
    select.value = character ? choice : 'off';
    lane.hidden = !character;
    document.body.classList.toggle('has-character', Boolean(character));
    if (!character) { sprite.style.animation = 'none'; return; }
    // All frames retain the source's 16 x 16 registration, scaled 4x with nearest-neighbor pixels.
    sprite.style.animation = 'none';
    sprite.style.backgroundImage = `url("${new URL(`sprites/${choice}-strip.png`, scriptBase).href}")`;
    sprite.style.backgroundSize = `${character.frames * 64}px 64px`;
    sprite.style.setProperty('--strip-end', `${-character.frames * 64}px`);
    void sprite.offsetWidth; // Restart both loops when the selected character changes.
    sprite.style.animation = `sprite-frames ${character.frames / 6}s steps(${character.frames}, end) infinite, sprite-travel 20s linear infinite`;
    sprite.dataset.character = choice;
    sprite.dataset.frames = String(character.frames);
    sprite.dataset.fps = '6';
  }
  select.onchange = () => {
    chosen = true; apply(select.value);
    ext.storage.local.set({ [key]: select.value }).catch(error => console.warn('Could not save projector character:', error));
  };
  apply('green');
  ext.storage.local.get(key).then(stored => {
    if (!chosen) apply(stored[key] === 'off' || characters[stored[key]] ? stored[key] : 'green');
  }).catch(() => {});
})();
