(function (root) {
  'use strict';
  const requestWords = ['help', 'check', 'stuck', 'grade', 'grading', 'lesson', 'assistance'];
  // These are ordinary words close to a keyword, not useful typo matches.
  const commonWords = new Set(['held', 'hell', 'heap', 'helm', 'heal', 'heel', 'cheek', 'chick', 'chuck', 'heck', 'stick', 'stack', 'stock', 'stunk', 'grape', 'grate', 'trade', 'grace', 'grave', 'grads', 'lessen', 'reading', 'trading', 'grinding', 'resistance']);
  const spellingCache = new Map();
  function distance(a, b) {
    const rows = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
    for (let i = 0; i <= a.length; i++) rows[i][0] = i;
    for (let j = 0; j <= b.length; j++) rows[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) {
      rows[i][j] = Math.min(rows[i - 1][j] + 1, rows[i][j - 1] + 1, rows[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) rows[i][j] = Math.min(rows[i][j], rows[i - 2][j - 2] + 1);
    }
    return rows[a.length][b.length];
  }
  function fuzzyWord(original) {
    const word = original.replace(/([a-z])\1{2,}/g, '$1$1');
    if (spellingCache.has(word)) return spellingCache.get(word);
    const match = !commonWords.has(word) && (word === 'chk' || /^(?:i?need)?(?:help|hlp|hepl)(?:me|please|pls|plz)$/.test(word) || /^(?:i?need)(?:help|hlp|hepl)$/.test(word) || requestWords.some(target => {
      const limit = target.length >= 7 ? 2 : 1;
      return word.length >= 3 && Math.abs(word.length - target.length) <= limit && distance(word, target) <= limit;
    }));
    if (spellingCache.size >= 2048) spellingCache.clear();
    spellingCache.set(word, match); return match;
  }
  const api = {
    parseDiscussion(url) {
      const u = new URL(url);
      const match = u.pathname.match(/^\/courses\/(\d+)\/discussion_topics\/(\d+)(?:\/|$)/);
      if (!match || u.protocol !== 'https:') throw new Error('Open a Canvas course discussion, then click the extension again.');
      return { origin: u.origin, courseId: match[1], topicId: match[2] };
    },
    isRequest(text, { fuzzy = true } = {}) {
      if (/\b(help|stuck|check|grade|grading|lesson|assistance)\b/i.test(text)) return true;
      if (!fuzzy) return false;
      const words = String(text).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().match(/[a-z]+/g) || [];
      return words.some(word => word.length <= 12 && fuzzyWord(word));
    },
    localDateKey(value = new Date()) {
      if (value == null || value === '') return null;
      const date = new Date(value);
      if (!Number.isFinite(date.getTime())) return null;
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    },
    partitionEntries(entries, done = {}, now = new Date()) {
      const day = api.localDateKey(now), today = [], earlier = [], completed = [];
      for (const entry of entries) {
        if (done[entry.id]) completed.push(entry);
        else if (api.localDateKey(entry.createdAt) === day) today.push(entry);
        else earlier.push(entry);
      }
      return { today, earlier, completed, day };
    },
    selectEntries(entries, { userId, mode = 'requests', includeOwn = false, fuzzy = true }, toText) {
      const unique = new Map(), deleted = new Set();
      for (const entry of entries) {
        const id = String(entry.id);
        // A deletion marker wins if a post changes while paginated results load.
        if (entry.deleted) { deleted.add(id); unique.delete(id); continue; }
        if (deleted.has(id) || entry.user_id == null || (!includeOwn && String(entry.user_id) === String(userId))) continue;
        const text = toText(entry.message || '').trim();
        if (!text || (mode !== 'all' && !api.isRequest(text, { fuzzy }))) continue;
        unique.set(id, {
          id, name: entry.user_name || 'Unnamed participant',
          text, createdAt: entry.created_at || null,
        });
      }
      return [...unique.values()].sort((a, b) => (Date.parse(a.createdAt) || 0) - (Date.parse(b.createdAt) || 0));
    },
    nextPage(link, origin, pathname) {
      const match = (link || '').match(/<([^>]+)>\s*;\s*rel="next"/i);
      if (!match) return null;
      const url = new URL(match[1], origin);
      if (url.origin !== origin || url.pathname !== pathname) throw new Error('Canvas returned an unexpected pagination link.');
      return url.href;
    },
    async getJSON(url, fetcher = fetch) {
      let response;
      try {
        response = await fetcher(url, {
          method: 'GET', credentials: 'same-origin', headers: { Accept: 'application/json' },
          cache: 'no-store', signal: AbortSignal.timeout(15000),
        });
      } catch (error) {
        throw new Error(error.name === 'TimeoutError' ? 'Canvas took too long to respond. Retrying shortly.' : 'Cannot reach Canvas. Check your connection; the queue will retry.');
      }
      if (!response.ok) {
        const errors = {
          401: 'Your Canvas login has expired. Sign in again, then refresh this page.',
          403: 'Canvas denied access. Check that you can view this discussion and its replies.',
          404: 'This discussion could not be found. Open the discussion itself and try again.',
          429: 'Canvas is limiting requests. Waiting before trying again.',
        };
        const error = new Error(errors[response.status] || `Canvas returned an error (${response.status}). Retrying shortly.`);
        if (response.status === 429) {
          const raw = response.headers.get('Retry-After');
          const ms = /^\d+(?:\.\d+)?$/.test(raw || '') ? Number(raw) * 1000 : Date.parse(raw) - Date.now();
          error.retryMs = Math.max(60000, Number.isFinite(ms) ? ms : 60000);
        }
        throw error;
      }
      if (response.redirected || !(response.headers.get('content-type') || '').includes('application/json')) {
        throw new Error('Canvas needs you to sign in. Sign in again and refresh this page.');
      }
      let data;
      try { data = JSON.parse((await response.text()).replace(/^while\(1\);\s*/, '')); }
      catch { throw new Error('Canvas returned an unreadable response. Retrying shortly.'); }
      return { data, link: response.headers.get('link') };
    },
    async fetchEntries(config, fetcher = fetch) {
      const path = `/api/v1/courses/${config.courseId}/discussion_topics/${config.topicId}/entries`;
      let url = `${config.origin}${path}?per_page=100`;
      const entries = [], visited = new Set();
      while (url) {
        if (visited.has(url) || visited.size >= 100) throw new Error('Discussion is too large or pagination repeated. Use a dedicated help discussion.');
        visited.add(url);
        const { data, link } = await api.getJSON(url, fetcher);
        if (!Array.isArray(data)) throw new Error('Canvas returned an unexpected discussion format.');
        entries.push(...data);
        url = api.nextPage(link, config.origin, path);
      }
      return entries;
    },
    waitingTime(date, now = Date.now()) {
      const stamp = Date.parse(date);
      if (!Number.isFinite(stamp)) return 'Time unavailable';
      const minutes = Math.max(0, Math.floor((now - stamp) / 60000));
      if (minutes < 1) return 'Just now';
      if (minutes < 60) return `${minutes} min`;
      if (minutes < 1440) return `${Math.floor(minutes / 60)} hr ${minutes % 60} min`;
      return `${Math.floor(minutes / 1440)} days`;
    },
  };
  root.CanvasHelpQueueCore = api;
  if (typeof module !== 'undefined') module.exports = api;
})(globalThis);
