'use strict';
const extension = typeof browser !== 'undefined' ? browser : chrome;

extension.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    const url = new URL(tab.url || '');
    if (url.protocol !== 'https:' || !/^\/courses\/\d+\/discussion_topics\/\d+(?:\/|$)/.test(url.pathname)) {
      await extension.tabs.create({ url: extension.runtime.getURL('start.html') });
      return;
    }
    await extension.scripting.executeScript({ target: { tabId: tab.id }, files: ['core.js', 'audio.js', 'content.js'] });
  } catch (error) {
    console.error('Could not open Help Queue:', error);
    await extension.tabs.create({ url: extension.runtime.getURL('start.html') });
  }
});

extension.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'chq:projector' && sender.tab?.id) {
    (async () => {
      if (typeof message.sourceKey !== 'string' || !message.sourceKey.startsWith('chq:v1:')) throw new Error('Open a connected discussion first.');
      if (Number.isInteger(message.windowId)) {
        try {
          await extension.windows.update(message.windowId, { focused: true });
          return { windowId: message.windowId };
        } catch { /* The previous projector window was closed. Open another. */ }
      }
      const query = new URLSearchParams({ sourceTab: String(sender.tab.id), sourceKey: message.sourceKey });
      const window = await extension.windows.create({
        url: extension.runtime.getURL(`projector.html?${query}`), type: 'popup', width: 960, height: 860,
      });
      return { windowId: window.id };
    })().then(sendResponse, error => sendResponse({ error: error.message }));
    return true;
  }
  if (message?.type !== 'chq:badge' || !sender.tab?.id) return;
  const count = Math.max(0, Math.min(9999, Number(message.count) || 0));
  const tabId = sender.tab.id;
  Promise.all([
    extension.action.setBadgeText({ tabId, text: message.error ? '!' : count ? String(count) : '' }),
    extension.action.setBadgeBackgroundColor({ tabId, color: message.error ? '#a33d28' : '#17675b' }),
    extension.action.setTitle({ tabId, title: message.error ? 'Help Queue: connection needs attention' : `Help Queue: ${count} waiting` }),
  ]).catch(() => {});
});

extension.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status !== 'loading') return;
  Promise.all([
    extension.action.setBadgeText({ tabId, text: '' }),
    extension.action.setTitle({ tabId, title: 'Open Canvas Help Queue' }),
  ]).catch(() => {});
});
